const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let registeredUsername = "";
let username = "";
const users = new Map();

// generate RSA key pair for this client
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    registeredUsername = input;
    username = input;
    console.log(`Welcome, ${username} to the chat`);

    // Send public key to server
    socket.emit("registerPublicKey", { username, publicKey });

    rl.prompt();

    rl.on("line", (message) => {
      if (message.trim()) {
        // Check for impersonate command
        if (message.startsWith("!impersonate ")) {
          username = message.split(" ")[1];
          console.log(`Now impersonating as ${username}`);
        }
        // Exit impersonate
        else if (message === "!exit") {
          username = registeredUsername;
          console.log(`Now you are ${username}`);
        }
        // Send message
        else {
          const payload = `${username}|${message}`;
          const signature = crypto
            .sign("sha256", Buffer.from(payload), privateKey)
            .toString("base64");

          socket.emit("message", { username, message, signature });
        }
      }
      rl.prompt();
    });
  });
});

socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username: newUser, publicKey: newPub } = data;
  users.set(newUser, newPub);
  console.log(`${newUser} join the chat`);
  rl.prompt();
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, signature } = data;


  if (senderUsername === registeredUsername && username === registeredUsername) {
    return;
  }

  // Do not display if impersonated and messages from impersonated username
  if (username !== registeredUsername && senderUsername === username) {
    return;
  }

  let isFake = false;

  // verification signature
  if (senderUsername === registeredUsername) {
    const payload = `${senderUsername}|${senderMessage}`;
    const pub = users.get(senderUsername);

    if (pub && signature) {
      try {
        const verified = crypto.verify(
          "sha256",
          Buffer.from(payload),
          pub,
          Buffer.from(signature, "base64")
        );
        if (!verified) {
          isFake = true;
        }
      } catch (err) {
        isFake = true;
      }
    }
  } else {
    const payload = `${senderUsername}|${senderMessage}`;
    const pub = users.get(senderUsername);

    if (!pub) {
      isFake = true;
    } else if (!signature) {
      isFake = true;
    } else {
      try {
        const verified = crypto.verify(
          "sha256",
          Buffer.from(payload),
          pub,
          Buffer.from(signature, "base64")
        );
        if (!verified) {
          isFake = true;
        }
      } catch (err) {
        isFake = true;
      }
    }
  }

  console.log(`${senderUsername}: ${senderMessage}`);
  if (isFake) {
    console.log("this user is fake");
  }
  rl.prompt();
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});