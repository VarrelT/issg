const io = require("socket.io-client");

// Import crypto module for hashing
const crypto = require("crypto");
const socket = io("http://localhost:3000");

socket.on("connect", () => {
  console.log("Connected to the server");
});

socket.on("disconnect", () => {
  console.log("Disconnected from server");
});

const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

let username = "";

socket.on("connect", () => {
  console.log("Connected to the server");
  
  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);
  });
});

rl.on("line", (message) => {
  if (message.trim()) {
    // Combines username and message with | as separator, then converts it to input hash and produces final hash in hexadecimal format.
    const hash = crypto
      .createHash("sha256")
      .update(`${username}|${message}`)
      .digest("hex");

    // send message with hash
    socket.emit("message", { username, message, hash });
  }
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage, hash } = data;

  //On receiving a message: recompute the hash of the received username|message. If different, print the warning message.

  const expectedHash = crypto
    .createHash("sha256")
    .update(`${senderUsername}|${senderMessage}`)
    .digest("hex");

  if (hash !== expectedHash) {
    console.warn("Warning: the message may have been changed during transmission");
  }

  if (senderUsername !== username) {
    console.log(`${senderUsername}: ${senderMessage}`);
  }
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});