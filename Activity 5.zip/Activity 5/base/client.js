const io = require("socket.io-client");

const socket = io("http://localhost:3000");

socket.on("connect", () => {
  console.log("Connected to the server");
});

socket.on("disconnect", () => {
  console.log("Disconnected from server");
});

const readline = require("readline");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

let username = "";

socket.on("connect", () => {
  console.log("Connected to the server");
  
  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);
  });
});

rl.on("line", (message) => {
  if (message.trim()) {
    socket.emit("message", { username, message });
  }
});

socket.on("message", (data) => {
  const { username: senderUsername, message: senderMessage } = data;
  if (senderUsername !== username) {
    console.log(`${senderUsername}: ${senderMessage}`);
  }
});

socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});