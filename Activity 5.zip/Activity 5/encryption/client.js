const io = require("socket.io-client");
const readline = require("readline");
const crypto = require("crypto");

const socket = io("http://localhost:3000");

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
  prompt: "> ",
});

let targetUsername = "";
let username = "";
const users = new Map();

// Generate RSA key pair
const { publicKey, privateKey } = crypto.generateKeyPairSync("rsa", {
  modulusLength: 2048,
  publicKeyEncoding: { type: "spki", format: "pem" },
  privateKeyEncoding: { type: "pkcs8", format: "pem" },
});

socket.on("connect", () => {
  console.log("Connected to the server");

  rl.question("Enter your username: ", (input) => {
    username = input;
    console.log(`Welcome, ${username} to the chat`);
    
    // Register public key
    socket.emit("registerPublicKey", { username, publicKey });

    rl.prompt();

    // secret message and exit secret chat
    rl.on("line", (message) => {
      if (message.trim()) {
        if (message.startsWith("!secret ")) {
          targetUsername = message.split(" ")[1];
          console.log(`Messages will be encrypted for ${targetUsername}`);
        } else if (message === "!exit") {
          targetUsername = "";
          console.log("Exiting secret chat mode");
        } else {
          try {
            let encryptedMessage = message;
            let isEncrypted = false;

            if (targetUsername && users.has(targetUsername)) {
              // Encrypt message for the target user
              const targetPublicKey = users.get(targetUsername);
              encryptedMessage = crypto.publicEncrypt(
                {
                  key: targetPublicKey,
                  padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
                },
                Buffer.from(message, 'utf-8')
              ).toString('base64');
              isEncrypted = true;
              console.log(`Message encrypted for ${targetUsername}`);
            }

            socket.emit("message", {
              username,
              message: encryptedMessage,
              encrypted: isEncrypted,
              target: targetUsername 
            });
          } catch (err) {
            console.log("Error encrypting message:", err.message);
          }
        }
      }
      rl.prompt();
    });
  });
});

socket.on("message", (data) => {
  const { username: senderUsername, message, encrypted, target } = data;
  try {
    if (encrypted) {
      // If we are the target the message will be decrypted using our private key and displayed in plaintext. If we are not the target then the message will remain displayed in ciphertext 
      if (target === username) {
        const decryptedMessage = crypto.privateDecrypt(
          {
            key: privateKey,
            padding: crypto.constants.RSA_PKCS1_OAEP_PADDING,
          },
          Buffer.from(message, 'base64')
        ).toString('utf-8');
        console.log(`${senderUsername}: ${decryptedMessage}`);
      } else {
        // For everyone show the ciphertext 
        console.log(`${senderUsername}: ${message}`);
      }
    } else {
      // Non encrypted message will show message normally
      console.log(`${senderUsername}: ${message}`);
    }
  } catch (err) {
    console.log(`${senderUsername}: ${message}`);
  }
  rl.prompt();
});

// Stores all user public keys in the users map. When a new user joins, their public key is added automatically.
socket.on("init", (keys) => {
  keys.forEach(([user, key]) => users.set(user, key));
  console.log(`\nThere are currently ${users.size} users in the chat`);
  rl.prompt();
});

socket.on("newUser", (data) => {
  const { username: newUser, publicKey: newPub } = data;
  users.set(newUser, newPub);
  console.log(`${newUser} joined the chat`);
  rl.prompt();
});


socket.on("disconnect", () => {
  console.log("Server disconnected, Exiting...");
  rl.close();
  process.exit(0);
});

rl.on("SIGINT", () => {
  console.log("\nExiting...");
  socket.disconnect();
  rl.close();
  process.exit(0);
});